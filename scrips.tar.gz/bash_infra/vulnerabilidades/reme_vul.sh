#!/bin/bash
#----------------------------------------------------#
#        --  Copyright (c) 2023-2024  --             #
#     Batch Actualizacion de vulnerabilidades        #
#                 CREADO POR:                        #
#         Gabriel Emilio Mendoza Cortes              #
#        --     FECHA DE CREACION:   --              #
#        --        08/12/2023        --              #
#      --     FECHA DE MODIFICACION:   --            #
#        --        10/06/2024        --              #
#        --      Periodicamente      --              #
#----------------------------------------------------#
        yum check-update > updates
        #cut -d" " -f1 updates > update2
        for ups in $(cut -d"." -f1 updates); do
                #echo las vulnerabilidades son $ups
                for vu in $(cut -d" " -f1 vulnerabilidades| grep $ups); do
                        versn=$(rpm -q $ups)
                                if [ $ups = $vu ]; then
                                        echo "***********************************************" 
                                        echo "******* Se remediara la vulnerabilidad $vu *******" 
                                        echo "******* Se encuentra en la version $versn *******" 
                                        yum update $vu -y >> v_1er_periodo_24-25.log 
                                        echo -e "se actualiza a la version \n$versn " 
                                        echo "***********************************************" 
                                        break
                                        #fi
                                else 
                                        echo "***********************************************" 
                                        echo "la vulnerabilidad $ups aun no tiene actualización" 
                                        echo "Se encuentra en la version $versn" 
                                        echo "***********************************************" 
                                        break
                                fi
        done
done

