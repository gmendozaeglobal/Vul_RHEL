#!/bin/bash
#archkrn=$()
#----------------------------------------------------#
#        --  Copyright (c) 2023-2024  --             #
#        Batch Actualizacion de Kernel               #
#                 CREADO POR:                        #
#         Gabriel Emilio Mendoza Cortes              #
#        --     FECHA DE CREACION:   --              #
#        --        08/12/2023        --              #
#      --     FECHA DE MODIFICACION:   --            #
#        --        10/06/2024        --              #
#        --      Periodicamente      --              #
#----------------------------------------------------#
#este for sirve para leer la lista de nombres de kernel 
for namkrn in $(cut -d" " -f1 wlistkr); do
    rpm -q $namkrn > kernels #esta parte crea el archivo de kernels instalados
    endkrn=$(tail -n1 kernels | cut -d" " -f1 ) #revisa el ultimo kernel instalado y lo guarda en la variable endkrn
    echo "El ultimo $namkrn instalado es $endkrn"
     for obs in $(cut -d" " -f1 kernels); do # este for sirve para leer el archivo kernels
       if [ $endkrn != $obs ]; then # est if revisa que los kernels obsoletos sean diferentes al ultimo kernel instalado
          echo -e "***----*** \n Se elimina el $namkrn : \n$obs \n ***----***" 
          rpm -e $obs
       else
          echo -e "***----*** \n Se mantiene la version de kernel : \n$endkrn \n ***----***"
          echo -e "***----***las versiones instaladas son \n $(rpm -q $namkrn)***----***"

       fi
     done     
done

