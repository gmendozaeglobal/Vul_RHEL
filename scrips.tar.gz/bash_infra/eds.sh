#!/bin/bash
#----------------------------------------------------#
#        --  Copyright (c) 2023-2024  --             #
# Batch Ejecutor de Scrips Kernel y Vulnerabilidades #
#                 CREADO POR:                        #
#         Gabriel Emilio Mendoza Cortes              #
#        --     FECHA DE CREACION:   --              #
#        --        15/12/2023        --              #
#      --     FECHA DE MODIFICACION:   --            #
#        --        10/06/2024        --              #
#        --      Periodicamente      --              #
#----------------------------------------------------#

cd /bash_infra/vulnerabilidades
./reme_vul.sh >> actu_vul_1er_periodo_24-25.log
yum update nss.x86_64 -y >> v_1er_periodo_24-25.log
echo "****************************************"
echo "**--terminamos con vulnerabilidades--***"
echo "****************************************"
echo "***---revisión de vulnerabilidades---***"
yum check-update
echo "****************************************"

cd /bash_infra/kernel
./krnls.sh >> actu_krnls_1er_periodo_24-25.log
echo "****************************************"
echo "*****----terminamos con kernel----******"
echo "****************************************"
echo "*****----------kernel-------------******"
rpm -q kernel
echo "*****------kernel-modules---------******"
rpm -q kernel-modules
echo "*****--------kernel-core----------******"
rpm -q kernel-core
echo "****************************************"
echo terminamos

